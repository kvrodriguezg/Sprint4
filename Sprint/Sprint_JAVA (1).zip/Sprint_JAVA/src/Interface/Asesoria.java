package Interface;


public interface Asesoria {

	//Declaración de método. 
	public String analizarUsuario();

}
