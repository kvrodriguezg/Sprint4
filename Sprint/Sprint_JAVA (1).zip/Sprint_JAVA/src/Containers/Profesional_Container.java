package Containers;
import java.util.List;
import java.util.Scanner;
import Entities.Profesional;
import Entities.Usuario;
import Interface.Asesoria;

public class Profesional_Container  extends Test implements Asesoria{

	Profesional prof = new Profesional();
	static Scanner reader = new Scanner(System.in);
	
	//Constructor con parámetros.
	public Profesional_Container(Profesional prof) {
		this.prof = prof;
	}
	
	//Constructor sin parámetros.
	public Profesional_Container() {	}

	//Método analizar usuario, utilizando el método ToString para desplegar datos de Profesional.
	@Override
	public String analizarUsuario() {
		
		return prof.toString();
	}
	
	//Método para añadir usuario del tipo profesional.
	public Profesional_Container(List<Usuario> lista) {
		
		System.out.println("Ingrese RUN de usuario:");
		prof.setRun(reader.nextInt());
		reader.nextLine();
		
		System.out.println("Ingrese Nombre de usuario:");
		prof.setNombre(reader.nextLine());
		
		System.out.println("Ingrese titulo:");
		prof.setTitulo(reader.nextLine());
		
		System.out.println("Ingrese fecha de ingreso:");
		prof.setFecha_ingreso(reader.nextLine());
		
		lista.add(prof);
	}

}
