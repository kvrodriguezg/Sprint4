package Containers;
import java.util.Scanner;
import java.util.List;

import Interface.Asesoria;
import Entities.Cliente;
import Entities.Usuario;

public class Cliente_Container implements Asesoria {
	
	static Scanner reader = new Scanner(System.in);
	Cliente cliente = new Cliente();
	
	//Constructor con parámetros.
	public Cliente_Container(Cliente cliente) {
		this.cliente = cliente;
	}
	
	//Constructor sin parámetros.
	public Cliente_Container() {} 
	
	//Método analizar cliente, utilizando el método ToString para desplegar datos de Cliente.
	@Override
	public String analizarUsuario() {
			
		return cliente.toString();
	}
	
	
	//Método que retorna nombres y apellidos de Cliente.
	public String obtenerNombre(String nombres,String apellidos)
	{
		String nombre_completo = nombres + " " + apellidos;
		return nombre_completo;
	}
	
	//Método que despliega el tipo de sistema de salud.
	public void obtenerSistemaSalud(int sis_salud)
	{
;
		if(sis_salud==1)
		{
			System.out.println("FONASA");
		}
		else if (sis_salud==2)
		{
			System.out.println("ISAPRE");
		}
	}
	
	
	//Método para añadir usuario del tipo cliente. Se validan requerimientos.
	public void addCliente(List<Usuario> lista) {
		
		int opcion=0;
		
		//Ingreso y validacion de RUN.
		System.out.println("Ingresar RUN de usuario:");
		int run = reader.nextInt();
		while(run>99999999) 
		{
			System.out.println("RUN no debe superar los 99.999.999. Ingrese nuevamente:");
			run = reader.nextInt();
		}
		cliente.setRun(run);
		reader.nextLine();
		
		//Ingreso y validacion de nombre de usuario.
		System.out.println("Ingresar Nombre de usuario:");
		String nombre = reader.nextLine();
		while( nombre.length()<10 || nombre.length()>50)
		{
			System.out.println("Nombre debe contener entre 10 y 50 caracteres. Ingrese nuevamente:");
			nombre = reader.nextLine();
		}
		cliente.setNombre(nombre);
		
		//Ingreso y validacion de nombre de RUT.
		System.out.println("Ingresar RUT de cliente:");
		int rut = reader.nextInt();
		while(rut>99999999) 
		{
			System.out.println("RUT no debe superar los 99.999.999. Ingrese nuevamente:");
			rut = reader.nextInt();
		}
		cliente.setRut(rut);
		reader.nextLine();
		
		//Ingreso y validacion de nombres. 
		System.out.println("Ingresar nombres:");
		String nombres = reader.nextLine();
		while( nombres.length()<5 || nombres.length()>30)
		{
			System.out.println("Nombres deben contener entre 5 y 30 caracteres. Ingrese nuevamente:");
			nombres = reader.nextLine();
		}
		cliente.setNombres(nombres);
		
		
		//Ingreso y validacion de apellidos. 
		System.out.println("Ingrese apellidos:");
		String apellidos = reader.nextLine();

		while( apellidos.length()<5 || apellidos.length()>30)
		{
			System.out.println("Apellidos deben contener entre 5 y 30 caracteres. Ingrese nuevamente:");
			apellidos = reader.nextLine();
		}
		cliente.setNombres(apellidos);
		
		//Ingreso y validación de telefono. 
		System.out.println("Ingrese telefono:");
		int tlf = reader.nextInt();
		cliente.setTelefono(tlf);
		reader.nextLine();
		
		//Ingreso y validacion de afp.
		System.out.println("Ingresar afp:");
		String afp = reader.nextLine();

		while( afp.length()<4 || apellidos.length()>30)
		{
			System.out.println("AFP debe contener entre 4 y 30 caracteres. Ingrese nuevamente:");
			afp = reader.nextLine();
		}
		cliente.setAfp(afp);
		
		//Ingreso y validación de sistema de salud.
		System.out.println("Ingresar Sistema de Salud:");
		System.out.println("Opción 1: FONASA");
		System.out.println("Opción 2: ISAPRE");
		
		opcion=reader.nextInt();
		
		while(opcion!=1 && opcion!=2)
		{
			System.out.println("Opción invalida.");
			System.out.println("Ingresar Sistema de Salud:");
			System.out.println("Opción 1: FONASA");
			System.out.println("Opción 2: ISAPRE");
			opcion=reader.nextInt();
		}
		cliente.setSis_salud(opcion);
		reader.nextLine();
		
		//Ingreso y validación de dirección.
		System.out.println("Ingresar dirección:");
		String direccion = reader.nextLine();
		while(direccion.length() > 70)
		{
			System.out.println("Dirección no debe superar los 70 caracteres. Ingrese nuevamente:");
			direccion = reader.nextLine();
		}
		cliente.setDireccion(direccion);
		
		//Ingreso y validación de comuna.
		System.out.println("Ingresar comuna:");
		String comuna = reader.nextLine();
		while(comuna.length() > 50)
		{
			System.out.println("Comuna no debe superar los 50 caracteres. Ingrese nuevamente:");
			comuna = reader.nextLine();
		}
		cliente.setComuna(comuna);
		
		//Ingreso y validación de edad.
		System.out.println("Ingresar Edad:");
		int edad = reader.nextInt();
		
		while (edad<0 || edad>=150)
		{
			System.out.println("Edad debe encontrarse entre 0 y 149. Ingrese nuevamente:");
			edad = reader.nextInt();
		}
		cliente.setEdad(edad);
		
		lista.add(cliente);
	}
}
