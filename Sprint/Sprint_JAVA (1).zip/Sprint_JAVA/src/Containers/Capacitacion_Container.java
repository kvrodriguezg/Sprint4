package Containers;
import java.util.List;
import java.util.Scanner;
import Entities.Capacitacion;

public class Capacitacion_Container {
	
	Capacitacion capacitacion = new Capacitacion();
	static Scanner reader = new Scanner(System.in);
	
	//Constructor sin parámetros.
	public Capacitacion_Container() {
		super();
	}

	//Constructor con parámetros.
	public Capacitacion_Container(Capacitacion capacitacion) {
		this.capacitacion = capacitacion;
	}

	//Método mostrarDetalle que retorna mensaje con el detalle de la capacitación.
	public String mostrarDetalle(String lugar,String hora,String dia, String duracion) {
		
		String mensaje = "La capacitación será en "+ lugar + " a las "+ hora + " del día "+
		dia + ", y durará "+ duracion + " minutos.";
 		return mensaje;
	}
	
	//Método para desplegar el detalle de la capacitación con método ToString().
	public String analizarCapacitacion() {
		
		return capacitacion.toString();
	}
	
	
	//Método para añadir capacitación. 
	public void addCapacitacion(List<Capacitacion> lista) {
		
		System.out.println("Ingrese ID de capacitación:");
		capacitacion.setId_cap(reader.nextInt());
		reader.nextLine();
		
		System.out.println("Ingrese RUT:");
		capacitacion.setRut(reader.nextInt());
		reader.nextLine();
		
		System.out.println("Ingrese día:");
		capacitacion.setDia(reader.nextLine());
		
		System.out.println("Ingrese hora:");
		capacitacion.setHora(reader.nextLine());
		
		System.out.println("Ingrese lugar:");
		capacitacion.setLugar(reader.nextLine());
		
		System.out.println("Ingrese duración:");
		capacitacion.setDuracion(reader.nextLine());
		
		System.out.println("Ingresar cantidad de asistentes:");
		capacitacion.setCant_a(reader.nextInt());
		reader.nextLine();
		
		lista.add(capacitacion);
	}

}
