package Containers;

public class Test {

	public void mostrar() {

	}

	public Test() {
		System.out.println("haga su primer ingreso");
	}

}
