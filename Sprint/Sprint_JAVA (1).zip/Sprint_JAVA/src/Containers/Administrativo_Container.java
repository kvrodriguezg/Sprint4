package Containers;

import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import Interface.Asesoria;
import Entities.Administrativo;
import Entities.Usuario;

public class Administrativo_Container extends Test implements Asesoria{

	Administrativo admin = new Administrativo();
	static Scanner reader = new Scanner(System.in);
		
	//Constructor con parámetros.
	public Administrativo_Container(Administrativo admin) {
		super();
		this.admin = admin;
	}
	
	//Constructor sin parámetros.
	public Administrativo_Container() {	}

	//Método analizar usuario, utilizando el método ToString para desplegar datos de administrativo.
	@Override
	public String analizarUsuario() {
		return admin.toString();
	}
	
	//Método para añadir usuario del tipo administrativo.
	public void addAdministrativo(List<Usuario> lista) {
		
		String num = "";
		System.out.println("Ingrese RUN de usuario:");
		num =reader.nextLine();
		while(isNumeric(num)) {
			System.out.println("ingree un numero valido");
		}
		admin.setRun(Integer.parseInt(num));
		
		reader.nextLine();
		String nombre = "";
		System.out.println("Ingrese Nombre de usuario:");
		nombre = reader.nextLine();
		
		while(Objects.isNull(nombre)) {
			System.out.println("ingrese un nombre: ");
			nombre = reader.nextLine();
		}
		
		admin.setNombre(nombre);	
		
		System.out.println("Ingrese área:");
		admin.setArea(reader.nextLine());
		
		System.out.println("Ingrese experiencia:");
		admin.setExp_previa(reader.nextLine());
		
		lista.add(admin);
	}
	
	private static boolean isNumeric(String cadena){
		try {
			Integer.parseInt(cadena);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
	
}
